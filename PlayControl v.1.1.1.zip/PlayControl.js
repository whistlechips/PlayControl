﻿'use strict';

window.DefineScript('PlayControl; Based on: \'track info + seekbar + buttons.js\' and \'last.fm lover.js\' by marc2003', {
  author: 'whistlechips',
  version: '1.1.0',
  options: {
    grab_focus: true
  }
}); 

include(fb.ProfilePath + 'PlayControl\\js\\PlayControl_last.fm.js');
include(fb.ProfilePath + 'PlayControl\\js\\PlayControl_helpers.js');
include(fb.ProfilePath + 'PlayControl\\js\\PlayControl_callbacks.js');

let panel = new _panel();
let seekbar = new _seekbar(0, 0, 0, 0);
let volbar = new _volume(0, 0, 0, 0);
let buttons = new _buttons();
let lastfm = new _lastfm();

function on_paint(gr) {

  gr.FillSolidRect(0, 0, panel.w, panel.h, colors.Background);
  ppt.panel_border ? gr.DrawRect(0, 0, panel.w-1, panel.h-1, 1, colors.SeekPlay) : '';
//  buttons.paint(gr);

  // get and display album art (or not)
  albumart = utils.GetAlbumArtV2(panel.metadb, 0);
  if (albumart && ppt.showalbumart) {
    _drawImage(gr, albumart, art.x, art.y, art.w, art.h);
    summ.x = art.x == 0 ? art.x + art.w + art_spc : art.w + (art.x + art_spc);
  } else 
    summ.x = 10;
  summ.y = art.y + ((art.h - (title.h() + artist.h() + album.h())) / 2);
  summ.w = (seekbar.x - handle.w - time.w) - summ.x;
 
  // NOTE: Please use the flag DT_NOPREFIX, or a '&' character will become an underline '_'
  ppt.summary ? gr.GdiDrawText(title.tf.Eval(), title.font(), !fb.IsPlaying || fb.IsPaused ? colors.TextNormal : colors.TextHighlight, summ.x, summ.y, summ.w, title.h(), DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_END_ELLIPSIS) : '';
  ppt.summary ? gr.GdiDrawText(artist.tf.Eval(), artist.font(), !fb.IsPlaying || fb.IsPaused ? colors.TextNormal : colors.TextHighlight, summ.x, summ.y + title.h(), summ.w, artist.h(), DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_END_ELLIPSIS) : '';
  ppt.summary ? gr.GdiDrawText(album.tf.Eval(), album.font(), !fb.IsPlaying || fb.IsPaused ? colors.TextNormal : colors.TextHighlight, summ.x, summ.y + title.h() + artist.h(), summ.w, album.h(), DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_END_ELLIPSIS) : '';

  gr.SetSmoothingMode(2); // Default: 0, HighSpeed: 1, HighQuality: 2, None: 3, AntiAlias: 4

  // User preferences for button filled background rounded rectangles and borders
  let pb_bg = new btn_bg(Math.floor(seekbar.x + ((seekbar.w - (ppt.play_btn_count * bs)) / 2)), ppt.play_btn_count * bs + _scale(6));
  let short_bg = new btn_bg(Math.floor(volbar.x + ((volbar.w - (ppt.short_btn_count * bs)) / 2)), ppt.short_btn_count * bs + _scale(6));
  ppt.play_btn_bg ?  gr.FillRoundRect( pb_bg.x, pb_bg.y(), pb_bg.w, pb_bg.h(), arc.bg, arc.bg, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekPlay  ) : '';
  ppt.play_btn_border ? gr.DrawRoundRect( pb_bg.x, pb_bg.y(), pb_bg.w, pb_bg.h(), arc.bg, arc.bg, 1, colors.SeekPlay  ) : '';
  ppt.short_btn_bg ? gr.FillRoundRect( short_bg.x, short_bg.y(), short_bg.w, short_bg.h(), arc.bg, arc.bg, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekPlay  ) : '';
  ppt.short_btn_border ? gr.DrawRoundRect( short_bg.x, short_bg.y(), short_bg.w, short_bg.h(), arc.bg, arc.bg, 1, colors.SeekPlay  ) : '';

  // seekbar: function FillRoundRect(): https://github.com/TheQwertiest/foo_spider_monkey_panel/blob/master/foo_spider_monkey_panel/js_backend/objects/gdi/gdi_graphics.cpp
  gr.FillRoundRect(seekbar.x, seekbar.y, seekbar.w, seekbar.h, arc.bar, arc.bar, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekPlay);
  if (fb.IsPlaying) {
    if (fb.PlaybackLength > 0) {
       // seekbar progress: qwr::QwrException::ExpectTrue( 2 * arc_width <= w   && 2 * arc_height <= h, "Arc argument has invalid value" );
      gr.FillRoundRect(seekbar.x, seekbar.y, seekbar.pos() + seekbar.h, seekbar.h, arc.bar, arc.bar, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekProgress);
      ppt.seekbar_border ? gr.DrawRoundRect(seekbar.x, seekbar.y, seekbar.w, seekbar.h, arc.bar, arc.bar, 1, colors.TextNormal) : '';
      // seekbar handle
      gr.FillEllipse(seekbar.x + seekbar.pos() - _scale(3), handle.y, handle.w, handle.h, !fb.IsPlaying || fb.IsPaused ? colors.TextHighlight & colors.TextNormal : colors.TextHighlight);
    }
  }

  // volume bar
  gr.FillRoundRect(volbar.x, volbar.y, volbar.w + _scale(6), volbar.h, arc.bar, arc.bar, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekPlay);
  gr.FillRoundRect(volbar.x, volbar.y, volbar.pos() + 10, volbar.h, arc.bar, arc.bar, !fb.IsPlaying || fb.IsPaused ? colors.SeekPause : colors.SeekProgress);
  ppt.seekbar_border ? gr.DrawRoundRect(volbar.x, volbar.y, volbar.w + _scale(6), volbar.h, arc.bar, arc.bar, 1, colors.TextNormal) : '';
  gr.FillEllipse(volbar.x + volbar.pos(), handle.y, handle.w, handle.h, !fb.IsPlaying || fb.IsPaused ? colors.TextHighlight & colors.TextNormal : colors.TextHighlight);

  // time elapsed / time remaining
	time.w = gr.CalcTextWidth(pb_time.tf.Eval(), pb_time.font()) + handle.w;
  time.h = pb_time.font().Height;
  time.x = seekbar.x - time.w - handle.w;// - _scale(10);
  time.y = seekbar.y - ((time.h - seekbar.h) / 2);

  gr.GdiDrawText(pb_time.tf.Eval(), pb_time.font(), !fb.IsPlaying || fb.IsPaused ? colors.TextNormal : colors.TextHighlight, time.x, time.y, time.w, time.h, DT_RIGHT | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX | DT_END_ELLIPSIS);
  gr.GdiDrawText(pb_len.tf.Eval(), pb_len.font(), !fb.IsPlaying || fb.IsPaused ? colors.TextNormal : colors.TextHighlight, seekbar.x + seekbar.w + handle.w + _scale(3), time.y, _scale(35), time.h, DT_LEFT | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX | DT_END_ELLIPSIS);

  buttons.paint(gr);
}

buttons.update = function () {

  let pbo_chrs = [chrs.repeat_off, chrs.repeat_all, chrs.repeat_one, chrs.random, chrs.shuffle, chrs.album, chrs.folder];
  let pbo_names = ['repeat_off', 'repeat_all', 'repeat_one', 'random', 'shuffle', 'album', 'folder'];
  let pbo = plman.PlaybackOrder; // 0-Default, 1-Repeat (Playlist),2-Repeat (Track),3-Random,4-Shuffle (tracks),5-Shuffle (albums),6-Shuffle (folders)
  let px = Math.floor(seekbar.x + ((seekbar.w - (ppt.play_btn_count * bs)) / 2)); // button x position for first playback button under seekbar.
  let fx = volbar.x + ((volbar.w - (ppt.short_btn_count * bs)) / 2); // button x position for first shortcut button under volume bar.
  let vm = fb.Volume.toFixed(2);
  let vb = vm == -100 ? chrs.mute : vm < -25 ? chrs.vol0 : vm < -10 ? chrs.vol1 : vm < -4 ? chrs.vol2 : chrs.vol3;

  lfm_button();
 
  // populate btn structures
  let lo = new btn(0, 'love', lfm_n, lfm_h, lfm_tip, lfm_func, px);
  let pr = new btn(1, 'prev', _chrToImg(chrs.prev, colors.TextNormal, fluent), _chrToImg(chrs.prev, colors.TextHighlight, fluent), 'Previous Track', function () { fb.Prev(); }, px);
  let re = new btn(2, 'rwind', _chrToImg(chrs.rwind, colors.TextNormal, fluent), _chrToImg(chrs.rwind, colors.TextHighlight, fluent), 'Rewind 10 Seconds', function () { fb.RunMainMenuCommand('Playback/Seek/Back by 10 seconds'); }, px);
  let pl = new btn(3, 'play', !fb.IsPlaying || fb.IsPaused ? _chrToImg(chrs.pause, colors.TextNormal, fluent) : _chrToImg(chrs.play, colors.TextHighlight, fluent), _chrToImg(chrs.play, colors.TextHighlight, fluent), 'click to play or pause', function () { fb.PlayOrPause(); }, px);
  let ff = new btn(4, 'ffwd', _chrToImg(chrs.ffwd, colors.TextNormal, fluent), _chrToImg(chrs.ffwd, colors.TextHighlight, fluent), 'Forward 30 Seconds', function () { fb.RunMainMenuCommand('Playback/Seek/Ahead by 30 seconds'); }, px);
  let ne = new btn(5, 'next', _chrToImg(chrs.next, colors.TextNormal, fluent), _chrToImg(chrs.next, colors.TextHighlight, fluent), 'Next Track', function () { fb.Next(); }, px);
  let pb = new btn(6, 'pbo', _chrToImg(pbo_chrs[pbo], colors.TextNormal, fluent), _chrToImg(pbo_chrs[pbo], colors.TextHighlight, fluent), 'Playback Order: ' + pbo_names[pbo], function () { pbo >= pbo_chrs.length - 1 ? plman.PlaybackOrder = 0 : plman.PlaybackOrder++ }, px);
  let pf = new btn(0, 'pref', _chrToImg(chrs.prf, colors.TextNormal, fluent), _chrToImg(chrs.prf, colors.TextHighlight, fluent), 'Preferences', function () { fb.ShowPreferences(); }, fx);
  let ds = new btn(1, 'dsp', _chrToImg(chrs.dsp, colors.TextNormal, fluent), _chrToImg(chrs.dsp, colors.TextHighlight, fluent), 'DSP Prefs', function () { fb.RunMainMenuCommand('Playback/DSP Settings/Preferences'); }, fx);
  let se = new btn(2, 'search', _chrToImg(chrs.search, colors.TextNormal, fluent), _chrToImg(chrs.search, colors.TextHighlight, fluent), 'Facets Search', function () { fb.RunMainMenuCommand('Library/Facets'); }, fx);
  let sa = new btn(3, 'save', _chrToImg(chrs.save, colors.TextNormal, fluent), _chrToImg(chrs.save, colors.TextHighlight, fluent), 'Save all playlists', function () { fb.RunMainMenuCommand('File/Save all playlists...'); }, fx);
  let sk = new btn(4, 'skip', _chrToImg(!fb.IsMainMenuCommandChecked('Playback/Skip tracks & use bookmarks') ? chrs.skipoff : chrs.skip, colors.TextNormal, fluent), _chrToImg(chrs.skip, colors.TextHighlight, fluent), 'Enable foo_skip component', function () { fb.RunMainMenuCommand('Playback/Skip tracks & use bookmarks'); }, fx);
  let vo = new btn(0, 'volume', _chrToImg(vb, colors.TextNormal, fluent), _chrToImg(vb, colors.TextHighlight, fluent), 'Volume: ' + vm + ' dB', function () { fb.VolumeMute(); });

  // create the buttons
  buttons.buttons.love =    new _button(lo.x(), lo.y(), lo.z(), lo.z(), { normal: lo.n, hover: lo.h }, lo.f, lo.t);
  buttons.buttons.prev =    new _button(pr.x(), pr.y(), pr.z(), pr.z(), { normal: pr.n, hover: pr.h }, pr.f, pr.t);
  buttons.buttons.rwind =   new _button(re.x(), re.y(), re.z(), re.z(), { normal: re.n, hover: re.h }, re.f, re.t);
  buttons.buttons.play =    new _button(pl.x(), pl.y(), pl.z(), pl.z(), { normal: pl.n, hover: pl.h }, pl.f, pl.t);
  buttons.buttons.next =    new _button(ne.x(), ne.y(), ne.z(), ne.z(), { normal: ne.n, hover: ne.h }, ne.f, ne.t);
  buttons.buttons.ffwd =    new _button(ff.x(), ff.y(), ff.z(), ff.z(), { normal: ff.n, hover: ff.h }, ff.f, ff.t);
  buttons.buttons.pbo =     new _button(pb.x(), pb.y(), pb.z(), pb.z(), { normal: pb.n, hover: pb.h }, pb.f, pb.t);
  buttons.buttons.pref =    new _button(pf.x(), pf.y(), pf.z(), pf.z(), { normal: pf.n, hover: pf.h }, pf.f, pf.t);
  buttons.buttons.dsp =     new _button(ds.x(), ds.y(), ds.z(), ds.z(), { normal: ds.n, hover: ds.h }, ds.f, ds.t);
  buttons.buttons.search =  new _button(se.x(), se.y(), se.z(), se.z(), { normal: se.n, hover: se.h }, se.f, se.t);
  buttons.buttons.save =    new _button(sa.x(), sa.y(), sa.z(), sa.z(), { normal: sa.n, hover: sa.h }, sa.f, sa.t);
  buttons.buttons.skip =    new _button(sk.x(), sk.y(), sk.z(), sk.z(), { normal: sk.n, hover: sk.h }, sk.f, sk.t);
  buttons.buttons.volume =  new _button(vo.x(), vo.y(), vo.z(), vo.z(), { normal: vo.n, hover: vo.h }, vo.f, vo.t);
  
};

function on_size() {
  panel.size();

  art.h = ppt.artsize >= 20 && ppt.artsize <= (panel.h - (art_spc * 2)) ? ppt.artsize : 60;
  art.w = art.h;
  art.x = art_spc;
  art.y = art_spc;//((panel.h - ((art_spc * 2) + art.h)) / 2) >= art_spc ? ((panel.h - ((art_spc * 2) + art.h)) / 2) : art_spc;// + (seekbar.y + seekbar.h);
   
  bar.h = ppt.seekbar_height >= 2 ? ppt.seekbar_height : 2;
  bar.y = art.y + art_spc;
  arc.bar = Math.floor(bar.h / 2), // diameter for FillRoundRect func for progress and volume bars
  arc.bg = Math.floor((bs - _scale(4)) / 2),

  seekbar.x = Math.round(panel.w / 3);
  seekbar.y = bar.y;
  seekbar.w = Math.round(panel.w / 3);
  seekbar.h = bar.h; //ppt.seekbar_height;

  volbar.y = bar.y;
  volbar.w = Math.round(panel.w / 6);
  volbar.x = Math.round(panel.w - volbar.w) - _scale(ppt.bs);
  volbar.h = bar.h;

  handle.h = Math.floor(ppt.seekbar_handle) > (bar.h * 2) ? (bar.h * 2) : Math.floor(ppt.seekbar_handle);
  handle.w = handle.h;
  handle.y = seekbar.y - ((handle.h - seekbar.h) / 2);

  title = new tfo(fb.TitleFormat(ppt.title), ppt.title_fsize, 1);
  artist = new tfo(fb.TitleFormat(ppt.artist), ppt.artist_fsize, 0);
  album = new tfo(fb.TitleFormat(ppt.album), ppt.album_fsize, 0);
  pb_time = new tfo(fb.TitleFormat(ppt.pb_time), 9, 0);
  pb_len = new tfo(fb.TitleFormat(ppt.pb_len), 9, 0);

  buttons.update();
};