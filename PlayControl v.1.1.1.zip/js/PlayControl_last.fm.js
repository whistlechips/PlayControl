﻿'use strict';

include(fb.ProfilePath + 'PlayControl\\js\\lastfm.js');

// marc2003 last.fm functionality. //////////////////////////////////////////////////////
function lfm_button() {
  switch (true) {
  case lastfm.username.length == 0 || lastfm.sk.length != 32:
    lfm_n = _chrToImg(chrs.info, colors.TextNormal, fluent);
    lfm_h = _chrToImg(chrs.info, colors.TextNormal, fluent);
    lfm_func = null;
    lfm_tip = 'Right click to set your Last.fm username and authorise.';
    break;
  case !panel.metadb:
    lfm_n = _chrToImg(chrs.info, colors.TextNormal, fluent);
    lfm_h = _chrToImg(chrs.info, colors.TextNormal, fluent);
    lfm_func = null;
    lfm_tip = 'No selection';
    break;
  case _.parseInt(panel.tf('%SMP_LOVED%')) == 1:
    lfm_n = _chrToImg(chrs.loved, colors.Heart, fluent);
    lfm_h = _chrToImg(chrs.unloved, colors.TextNormal, fluent);
    lfm_func = function () {
      lastfm.post('track.unlove', null, panel.metadb);
    }
    lfm_tip = panel.tf('Unlove "%title%" by "%artist%"');
    break;
  default:
    lfm_n = _chrToImg(chrs.unloved, colors.TextNormal, fluent);
    lfm_h = _chrToImg(chrs.loved, colors.Heart, fluent);
    lfm_func = function () {
      lastfm.post('track.love', null, panel.metadb);
    }
    lfm_tip = panel.tf('Love "%title%" by "%artist%"');
  };
};

function on_mouse_rbtn_up(x, y) {
  if (buttons.buttons.love.trace(x, y)) {
    const flag = lastfm.username.length ? MF_STRING : MF_GRAYED;
    let m = window.CreatePopupMenu();
    m.AppendMenuItem(MF_STRING, 1, 'Last.fm username...');
    m.AppendMenuItem(flag, 2, 'Authorise');
    m.AppendMenuItem(flag, 3, 'Bulk import Last.fm loved tracks');
    m.AppendMenuItem(MF_STRING, 4, 'Show loved tracks');
    m.AppendMenuItem(MF_STRING, 5, 'Configure...');
    const idx = m.TrackPopupMenu(x, y); 
    switch (idx) {
    case 1:
      lastfm.update_username();
      break;
    case 2:
      lastfm.post('auth.getToken');
      break;
    case 3:
      lastfm.get_loved_tracks(1);
      break;
    case 4:
      fb.ShowLibrarySearchUI('%SMP_LOVED% IS 1');
      break;
    case 5:
      window.ShowConfigure();
      break;
    }
  } else {
    panel.rbtn_up(x, y);
  }
  return true;
};

function on_notify_data(name, data) {
  lastfm.notify_data(name, data);
};

