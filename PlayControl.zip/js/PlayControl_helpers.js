﻿'use strict';

include(fb.ProfilePath + 'PlayControl\\js\\lodash.min.js');
include(fb.ProfilePath + 'PlayControl\\js\\panel.js');
include(fb.ProfilePath + 'PlayControl\\js\\seekbar.js');
include(fb.ProfilePath + 'PlayControl\\js\\volume.js');
include(fb.ProfilePath + 'PlayControl\\js\\albumart.js');
include(fb.ProfilePath + 'PlayControl\\js\\helpers.js');

function _gdiFont(name, size, style) {
	return gdi.Font(name, _scale(size), style);
}

function _chrToImg(chr, colour, font) {
	const size = 96;
	let temp_bmp = gdi.CreateImage(size, size);
	let temp_gr = temp_bmp.GetGraphics();
	temp_gr.SetTextRenderingHint(4);
	temp_gr.DrawString(chr, font || fontawesome, colour, 0, 0, size, size, SF_CENTRE);
	temp_bmp.ReleaseGraphics(temp_gr);
	temp_gr = null;
	return temp_bmp;
}

// user switchable button surrounds/backgrounds
function btn_bg (x, w) {
  this.x = x;
  this.y = function () {
    return (seekbar.y + seekbar.h + _scale(4)) + _scale(1.5);
  };
  this.w = w;
  this.h = function () {
    return Math.floor(bs - _scale(4));
  };
};

// objects for text elements
function tfo(tf, fsize, style) {
  this.tf = tf;
  this.fsize = fsize;
  this.style = style;
  this.font = function () {
    return utils.CheckFont("Roboto") ? _gdiFont("Roboto", this.fsize, this.style) : _gdiFont("Segoe UI", this.fsize, this.style);
  };
  this.h = function () {
    return this.font().Height * 1.2;
  };
};

function make_rgb(a) {
  let b = a.split(",");
  return _RGB(b[0], b[1], b[2]);
};

let ppt = {
  artist: window.GetProperty('Now Playing Artist TitleFormat', '[%artist%]  •  [%album%][  •  %date%]'),
  title: window.GetProperty('Now Playing Title TitleFormat', '[%title%]'),
  album: window.GetProperty('Now Playing Album TitleFormat', '%bitrate% kbs  •  %codec% %codec_profile%  •  %samplerate% Hz  •  $caps(%channels%)  •  %filesize_natural%'),
  pb_time: window.GetProperty('Now Playing Playback Time TitleFormat', '[%playback_time%] '),
  pb_len: window.GetProperty('Now Playing Playback Length TitleFormat', '[%playback_time_remaining%]'),
  textnormal: window.GetProperty('Custom Color Normal Text (r,g,b)', '160,160,160'),
  texthighlight: window.GetProperty('Custom Color Highlight Text (r,g,b)', '255,255,255'),
  background: window.GetProperty('Custom Color Background (r,g,b)', '32,32,32'),
  seekprog: window.GetProperty('Custom Color Seekbar Progress (r,g,b)', '200,97,44'),
  seekplay: window.GetProperty('Custom Color Seekbar Play (r,g,b)', '64,64,64'),
  seekpause: window.GetProperty('Custom Color Seekbar Paused (r,g,b)', '16,16,16'),
  heart: window.GetProperty('Custom Color Love Heart (r,g,b)', '95,0,16'),
  showalbumart: window.GetProperty('Now Playing Album Art', true),
  artsize: window.GetProperty('Now Playing Album Art Size (px)', 60),
  summary: window.GetProperty('Now Playing Text Display', true),
  title_fsize: window.GetProperty('Now Playing Title Font Size', 10),
  artist_fsize: window.GetProperty('Now Playing Artist Font Size', 9),
  album_fsize: window.GetProperty('Now Playing Album Font Size', 8),
  bs: window.GetProperty('Panel Button Size (20-40px)', 28),
  play_btn_bg: window.GetProperty('Panel Transport Button Background', false),
  play_btn_border: window.GetProperty('Panel Transport Button Border', false),
  short_btn_bg: window.GetProperty('Panel Shortcut Button Background', false),
  short_btn_border: window.GetProperty('Panel Shortcut Button Border', false),
  seekbar_border: window.GetProperty('Seekbar Border', false),
//  volbar_border: window.GetProperty('Volume Bar Border', false),
  panel_border: window.GetProperty('Panel Border', false),
  seekbar_handle: window.GetProperty('Seekbar Handle Size (px)', 12),
  seekbar_height: window.GetProperty('Seekbar Thickness (px)', 6),
  play_btn_count: 7, // number of playback and shortcut control buttons under seekbar and volume bar.
  short_btn_count: 5,
};

const chrs = {
  prf: '\ue713',
  prev: '\ue892',
  rwind: '\ued3c', //'\ueb9e',
  play: '\uF5B0',
  pause: '\ue768',
  ffwd: '\ued3d', //'\ueb9d',
  next: '\ue893',
  save: '\ue78c',
  search: '\ue721',
  dsp: '\uf8a6', //'\uF4C3',
  mute: '\ue74f',
  vol0: '\ue992',
  vol1: '\ue993',
  vol2: '\ue994',
  vol3: '\ue995',
  repeat_all: '\ue8ee',
  repeat_one: '\ue8ed',
  repeat_off: '\uf5e7',
  shuffle: '\ue8b1',
  random: '\ue9ce',
  album: '\ue93c',
  folder: '\ued25',
  skipoff: '\uf0b5', //'\uf204',
  skip: '\uea98', //'\uf205',
  info: '\uE9CE',
  loved: '\uE0A5',
  unloved: '\uE006',
};

let bs = Math.floor(ppt.bs >= 20 && ppt.bs <= 40 ? _scale(ppt.bs) : _scale(28));
let lfm_n, lfm_h, lfm_func, lfm_tip;
let albumart = null;
let art = {x: 0, y: 0, w: 0, h: 0};
let time = {x: 0, y: 0, w: 0, h: 0};
let handle = {w: 0, h: 0, y: 0};
let bar = {h: 0, y: 0};
let arc = {bar: 0, bg: 0};// diameter for FillRoundRect func for progress and volume bars
let summ = {x: 0, y: 0, w: 0};
let awesome = _gdiFont('FontAwesome', 43, 0); // regular: 0, bold: 1, italic: 2, bold_italic: 3, underline: 4, strikeout: 8
let fluent = _gdiFont('Segoe Fluent Icons', 38, 0);
let title, artist, album, pb_time, pb_len;


let colors = {
  SeekPause: make_rgb(ppt.seekpause),
  SeekPlay: make_rgb(ppt.seekplay),
  TextNormal: make_rgb(ppt.textnormal),
  TextHighlight: make_rgb(ppt.texthighlight),
  Heart: make_rgb(ppt.heart),
  SeekProgress: make_rgb(ppt.seekprog),
  Background: make_rgb(ppt.background),
};

const _tooltip = utils.CheckFont("Roboto") ? window.CreateTooltip('Roboto', _scale(7)) : window.CreateTooltip('Segoe UI', _scale(7)); // I don't know why this overrides function tooltip() is helper.js.

function btn(c, d, n, h, t, f, e, z, s) {
  this.c = c; //index
  this.d = d; //designator
  this.n = n; //normal char
  this.h = h; //hover char
  this.t = t; //tip
  this.f = f; //function/command
  this.e = e; //button type: play cntrl (px) or function (fx)
  this.x = function () {
    switch (true) {
    case this.d == 'play':
      return this.e + (bs * this.c) - (bs / 4);
      break;
    case this.d == 'volume':
      return volbar.x - bs;
      break;
    default:
      return this.e + (bs * this.c);
    };
  };
  this.y = function () {
    switch (true) {
    case this.d == 'play':
      return (seekbar.y + seekbar.h + _scale(4)) - (bs * .25);
      break;
    case this.d == 'volume':
      return  volbar.y - ((bs - volbar.h) / 2);
      break;
    default:
      return (seekbar.y + seekbar.h + _scale(4));
    };
  };
  this.z = function () { //button size
    return this.d == 'play' ? bs * 1.5 : bs;
  };
  this.s = function () { //button char change based on state
    switch (true) {
    case this.d == 'play':
      return !fb.IsPlaying || fb.IsPaused ? this.h : this.n;
      break;
    case this.d == 'skip':
      return !fb.IsMainMenuCommandChecked('Playback/Skip tracks & use bookmarks') ? this.n : this.h;
      break;
    default:
      return this.n;
    };
  };
};


